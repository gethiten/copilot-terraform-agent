"""
Copilot Terraform Agent - Copilot Studio Backend
This app provides API endpoints (actions) for Microsoft Copilot Studio agent.
Copilot Studio handles Terraform generation; this backend commits code to GitHub.
No Azure OpenAI or Foundry dependency - all AI is handled by Copilot Studio.
"""

import os
import json
import re
import requests
from datetime import datetime
from pathlib import Path
from flask import Flask, request, jsonify, render_template
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)

# =============================================================================
# CONFIGURATION
# =============================================================================

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
GITHUB_REPO_URL = os.getenv("GITHUB_REPO_URL")
OUTPUT_DIRECTORY = os.getenv("OUTPUT_DIRECTORY", "generated_terraform")


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def parse_terraform_blocks(terraform_code: str) -> dict:
    """Extract Terraform code blocks from the response."""
    blocks = {
        'providers.tf': '',
        'variables.tf': '',
        'main.tf': '',
        'outputs.tf': ''
    }
    
    # Find all HCL code blocks
    pattern = r'```(?:hcl|terraform)?\s*\n(.*?)```'
    matches = re.findall(pattern, terraform_code, re.DOTALL)
    
    if not matches:
        # If no code blocks, treat entire response as main.tf
        blocks['main.tf'] = terraform_code.strip()
        return blocks
    
    # Categorize blocks based on content
    for i, block in enumerate(matches):
        block = block.strip()
        if not block:
            continue
            
        if 'terraform {' in block or 'provider "' in block:
            blocks['providers.tf'] += block + '\n\n'
        elif 'variable "' in block:
            blocks['variables.tf'] += block + '\n\n'
        elif 'output "' in block:
            blocks['outputs.tf'] += block + '\n\n'
        else:
            blocks['main.tf'] += block + '\n\n'
    
    # Clean up
    for key in blocks:
        blocks[key] = blocks[key].strip()
    
    return blocks


def save_terraform_files(blocks: dict, prompt: str) -> str:
    """Save Terraform files to disk."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(OUTPUT_DIRECTORY) / f"terraform_{timestamp}"
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Save each file
    for filename, content in blocks.items():
        if content:
            file_path = output_dir / filename
            with open(file_path, 'w') as f:
                f.write(content)
    
    # Save metadata
    metadata = {
        "prompt": prompt,
        "timestamp": timestamp,
        "files": [f for f, c in blocks.items() if c]
    }
    with open(output_dir / "metadata.json", 'w') as f:
        json.dump(metadata, f, indent=2)
    
    # Create README
    readme = f"""# Generated Terraform Configuration

## Prompt
{prompt}

## Generated Files
{chr(10).join(['- ' + f for f in metadata['files']])}

## Usage
```bash
terraform init
terraform plan
terraform apply
```

## Generated
{datetime.now().isoformat()}
"""
    with open(output_dir / "README.md", 'w') as f:
        f.write(readme)
    
    return str(output_dir)


def create_github_pr(terraform_blocks: dict, prompt: str, branch_name: str = None) -> dict:
    """Create a GitHub PR with the generated Terraform code."""
    if not GITHUB_TOKEN or not GITHUB_REPO_URL:
        return {"error": "GitHub not configured"}
    
    # Parse repo info
    match = re.match(r'https://github\.com/([^/]+)/([^/\.]+)', GITHUB_REPO_URL)
    if not match:
        return {"error": "Invalid GitHub repo URL"}
    
    owner, repo = match.groups()
    headers = {
        "Authorization": f"Bearer {GITHUB_TOKEN}",
        "Accept": "application/vnd.github.v3+json"
    }
    
    try:
        # Get default branch SHA
        ref_response = requests.get(
            f"https://api.github.com/repos/{owner}/{repo}/git/ref/heads/main",
            headers=headers
        )
        if ref_response.status_code != 200:
            return {"error": "Failed to get main branch"}
        
        base_sha = ref_response.json()["object"]["sha"]
        
        # Create new branch
        if not branch_name:
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            branch_name = f"terraform/copilot-{timestamp}"
        
        requests.post(
            f"https://api.github.com/repos/{owner}/{repo}/git/refs",
            headers=headers,
            json={"ref": f"refs/heads/{branch_name}", "sha": base_sha}
        )
        
        # Create files in the branch
        folder_name = f"deployments/{branch_name.replace('/', '-')}"
        
        for filename, content in terraform_blocks.items():
            if content:
                file_path = f"{folder_name}/{filename}"
                requests.put(
                    f"https://api.github.com/repos/{owner}/{repo}/contents/{file_path}",
                    headers=headers,
                    json={
                        "message": f"Add {filename}",
                        "content": __import__('base64').b64encode(content.encode()).decode(),
                        "branch": branch_name
                    }
                )
        
        # Create PR
        pr_response = requests.post(
            f"https://api.github.com/repos/{owner}/{repo}/pulls",
            headers=headers,
            json={
                "title": f"🤖 Copilot: {prompt[:60]}{'...' if len(prompt) > 60 else ''}",
                "body": f"## Terraform Infrastructure Request\n\n**Prompt:** {prompt}\n\n---\n\n*Generated by Copilot Terraform Agent*",
                "head": branch_name,
                "base": "main"
            }
        )
        
        if pr_response.status_code == 201:
            pr_data = pr_response.json()
            return {
                "success": True,
                "pr_url": pr_data["html_url"],
                "pr_number": pr_data["number"],
                "branch_name": branch_name
            }
        else:
            return {"error": f"Failed to create PR: {pr_response.text}"}
            
    except Exception as e:
        return {"error": str(e)}


# =============================================================================
# API ENDPOINTS FOR COPILOT STUDIO
# =============================================================================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint for Copilot Studio custom connector."""
    return jsonify({
        "status": "healthy",
        "service": "Copilot Terraform Agent",
        "version": "2.0.0",
        "description": "Backend actions for Copilot Studio Terraform agent",
        "github_configured": bool(GITHUB_TOKEN and GITHUB_REPO_URL)
    })


@app.route('/api/copilot/generate', methods=['POST'])
def copilot_generate():
    """
    Commit Terraform code to GitHub and create a PR.
    This endpoint receives Terraform code generated by Copilot Studio.
    
    Request Body:
    {
        "terraform_code": "terraform { ... }",
        "description": "Create a storage account with blob container",
        "location": "eastus",
        "create_pr": true
    }
    
    Response:
    {
        "success": true,
        "pr_url": "https://github.com/...",
        "message": "..."
    }
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('terraform_code'):
            return jsonify({
                "success": False,
                "error": "terraform_code is required. Copilot Studio should generate the Terraform code."
            }), 400
        
        terraform_code = data['terraform_code']
        description = data.get('description', 'Infrastructure deployment')
        location = data.get('location', 'eastus')
        create_pr = data.get('create_pr', True)
        
        print(f"\n{'='*60}")
        print("🤖 Copilot Studio - Commit Terraform Request")
        print(f"{'='*60}")
        print(f"Description: {description}")
        print(f"Location: {location}")
        print(f"Code length: {len(terraform_code)} chars")
        print(f"{'='*60}\n")
        
        # Parse the Terraform code into files
        terraform_blocks = parse_terraform_blocks(terraform_code)
        
        # Save to disk
        saved_path = save_terraform_files(terraform_blocks, description)
        print(f"💾 Saved to: {saved_path}")
        
        # Create PR if requested
        pr_result = {}
        if create_pr:
            pr_result = create_github_pr(terraform_blocks, description)
            if pr_result.get('success'):
                print(f"✅ PR created: {pr_result['pr_url']}")
        
        # Build response message
        if pr_result.get('success'):
            message = f"✅ Terraform code committed and PR created for review."
        else:
            message = f"✅ Terraform code saved successfully."
            if pr_result.get('error'):
                message += f" (GitHub: {pr_result['error']})"
        
        return jsonify({
            "success": True,
            "files": terraform_blocks,
            "saved_path": saved_path,
            "pr_url": pr_result.get('pr_url'),
            "pr_number": pr_result.get('pr_number'),
            "branch_name": pr_result.get('branch_name'),
            "message": message
        })
        
    except Exception as e:
        print(f"⚠️ Error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500


@app.route('/api/copilot/status/<pr_number>', methods=['GET'])
def copilot_pr_status(pr_number):
    """
    Check the status of a PR.
    
    Response:
    {
        "pr_number": 123,
        "state": "open|closed|merged",
        "deployment_status": "pending|success|failure"
    }
    """
    try:
        if not GITHUB_TOKEN or not GITHUB_REPO_URL:
            return jsonify({"error": "GitHub not configured"}), 500
        
        match = re.match(r'https://github\.com/([^/]+)/([^/\.]+)', GITHUB_REPO_URL)
        if not match:
            return jsonify({"error": "Invalid repo configuration"}), 500
        
        owner, repo = match.groups()
        headers = {
            "Authorization": f"Bearer {GITHUB_TOKEN}",
            "Accept": "application/vnd.github.v3+json"
        }
        
        # Get PR info
        pr_response = requests.get(
            f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}",
            headers=headers
        )
        
        if pr_response.status_code != 200:
            return jsonify({"error": "PR not found"}), 404
        
        pr_data = pr_response.json()
        state = pr_data.get('state')
        merged = pr_data.get('merged', False)
        
        if merged:
            deployment_status = "deployed"
            message = "✅ Infrastructure has been deployed."
        elif state == 'closed':
            deployment_status = "cancelled"
            message = "❌ PR was closed without merging."
        else:
            deployment_status = "pending_review"
            message = "⏳ PR is awaiting review and approval."
        
        return jsonify({
            "success": True,
            "pr_number": int(pr_number),
            "pr_url": pr_data.get('html_url'),
            "state": state,
            "merged": merged,
            "deployment_status": deployment_status,
            "message": message,
            "title": pr_data.get('title')
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/templates', methods=['GET'])
def list_templates():
    """
    List available Terraform templates.
    Useful for Copilot Studio to show options to users.
    """
    templates = [
        {
            "id": "storage",
            "name": "Storage Account",
            "description": "Azure Storage Account with blob container",
            "prompt": "Create an Azure Storage Account with a blob container"
        },
        {
            "id": "webapp",
            "name": "Web App",
            "description": "Azure App Service with App Service Plan",
            "prompt": "Create an Azure App Service with App Service Plan"
        },
        {
            "id": "function",
            "name": "Function App",
            "description": "Azure Function App with consumption plan",
            "prompt": "Create an Azure Function App with consumption plan and storage"
        },
        {
            "id": "vm",
            "name": "Virtual Machine",
            "description": "Azure Virtual Machine with networking",
            "prompt": "Create an Azure Linux Virtual Machine with VNet, subnet, and public IP"
        },
        {
            "id": "aks",
            "name": "Kubernetes Cluster",
            "description": "Azure Kubernetes Service cluster",
            "prompt": "Create an Azure Kubernetes Service cluster with 2 nodes"
        },
        {
            "id": "cosmosdb",
            "name": "Cosmos DB",
            "description": "Azure Cosmos DB account with SQL API",
            "prompt": "Create an Azure Cosmos DB account with SQL API database and container"
        }
    ]
    
    return jsonify({
        "success": True,
        "templates": templates
    })


# =============================================================================
# WEB INTERFACE
# =============================================================================

@app.route('/')
def index():
    """Simple web interface for testing."""
    return render_template('index.html')


# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':
    host = os.getenv('FLASK_HOST', '0.0.0.0')
    port = int(os.getenv('FLASK_PORT', 5001))
    debug = os.getenv('FLASK_DEBUG', 'True').lower() == 'true'
    
    print("="*60)
    print("🤖 Copilot Terraform Agent (Copilot Studio Backend)")
    print("="*60)
    print("Mode: Copilot Studio handles AI/Terraform generation")
    print(f"GitHub: {'✅ Configured' if GITHUB_TOKEN else '❌ Not configured'}")
    print(f"Listening on: http://{host}:{port}")
    print("="*60)
    
    app.run(host=host, port=port, debug=debug)
